

function SignIn() {
  return (
    <div>
      <h1>PAGINA DE LOGIN</h1>
    </div>
  );
}

export default SignIn;
