
export default function Dashboard(){
  return(
    <div>
      <h1>PAGINA DASHBOARD</h1>
    </div>
  )
}