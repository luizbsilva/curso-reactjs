
function SignUp() {
  return (
    <div>
      <h1>TELA DE CADASTRO</h1>
    </div>
  );
}

export default SignUp;
