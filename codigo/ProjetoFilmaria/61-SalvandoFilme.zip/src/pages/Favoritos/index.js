
export default function Favoritos(){
  return(
    <div>
      <h1>Pagina Filmes Favoritos</h1>
    </div>
  )
}