import './styles.css';
import Routes from './routes';

export default function App() {
 return (
   <div className="app">
     <Routes/>
   </div>
 );
}